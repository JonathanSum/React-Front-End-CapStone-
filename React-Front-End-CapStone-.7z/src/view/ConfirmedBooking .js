import React from "react";

const ConfirmedBooking = () => {
  return <div>ConfirmedBooking </div>;
};

export default ConfirmedBooking;
