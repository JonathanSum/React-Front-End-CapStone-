import React from "react";

const CustomersSay = () => {
  return <div>CustomersSay</div>;
};

export default CustomersSay;
